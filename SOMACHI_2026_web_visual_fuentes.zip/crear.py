from pathlib import Path
import base64, re, io
import matplotlib
matplotlib.use('Agg')
from matplotlib.mathtext import math_to_image
from matplotlib.font_manager import FontProperties
matplotlib.rcParams.update({'mathtext.fontset':'cm','svg.fonttype':'path','savefig.transparent':True})
p=Path(__file__).resolve().parent
source=(p/'plantilla_base.html').read_text()
css=source[source.index('<style>')+7:source.index('</style>')]
css += '''\n.progress{grid-template-columns:repeat(13,1fr)} svg{max-height:49svh;min-height:200px} .plot-note{font-size:10px}.legend{font-size:12px;margin:9px 0 4px}.formula{background:transparent;border:0;margin:12px 0;padding:0;min-height:0}.eq{display:block;max-width:100%;height:auto;margin:8px auto;width:auto}.formula .eq{max-height:43px}.intro .eq{max-height:48px;margin:11px auto}.end .eq{max-height:55px;margin:15px auto}.credit{font-size:11px}.visual-note{font-size:11px;color:var(--muted);margin:6px 0 0}#desc{min-height:0}.intro{padding:19px 16px}.intro p{margin-bottom:0} @media(max-height:700px){svg{max-height:43svh;min-height:190px}}'''
# Reuse the original exact orbital drawing and SVG helper functions.
helper=source[source.index('function poly('):source.index('function sample(')]
helper=helper.replace('D.R','R')
# Omit the old wedge and radial functions: the orange region is now an unbounded wedge clipped only by the viewport.
helper=helper[:helper.index('function wedge(')]+helper[helper.index('function background('):]
# Render formula typography as vector Computer Modern, close to the poster's Latin Modern.
def eq(s,alt,fs=23):
    b=io.BytesIO(); math_to_image('$'+s+'$',b,prop=FontProperties(size=fs),format='svg',color='#183b50')
    svg=b.getvalue(); return '<img class="eq" alt="'+alt+'" src="data:image/svg+xml;base64,'+base64.b64encode(svg).decode()+'">'
logo='data:image/png;base64,'+base64.b64encode((p/'Escudo_uaustralchile.png').read_bytes()).decode()
introeq=eq(r'\partial_t z=\Delta z+z^p','Derivada temporal de z igual a laplaciano de z más z elevado a p.',26)+eq(r'z(x,0)=z_0(x),\quad p\geq3','Dato inicial y p mayor o igual a 3.',22)
floweq=eq(r'w\prime=w^4','Flujo holomorfo w prima igual a w a la cuarta.')
endeq=eq(r'T_{\max}=\infty','Existencia global.',26)+eq(r'\lim_{t\to\infty}\|z(\cdot,t)\|_\infty=0','Convergencia uniforme a cero.',24)
hyp=eq(r'\overline{\mathrm{Im}(0)}\subset W_m','La clausura de la imagen inicial está contenida en el sector atractor.',23)
html='''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#ffffff"><title>Calor complejo · SOMACHI 2026</title><style>'''+css+'''</style></head><body><main>
<header><img alt="Escudo Universidad Austral de Chile" src="'''+logo+'''"><div><b>SOMACHI 2026</b><small>Universidad Austral de Chile<br>Magíster en Matemáticas</small></div><button class="reset" id="reset" aria-label="Volver al inicio">↻</button></header>
<div class="progress-head"><span id="phase"></span><span id="count"></span></div><div class="progress" id="progress" aria-label="Pasos del recorrido"></div>
<section class="step"><h1 id="title"></h1><p id="desc" aria-live="polite"></p>
<div id="intro" class="intro" hidden>'''+introeq+'''<p style="text-align:center;margin-top:14px">¿Cuándo existe la solución para todo tiempo y converge uniformemente a cero?</p><div class="sequence"><div><i style="background:var(--blue)">1</i> Acotar la imagen</div><div><i style="background:var(--orange)">2</i> Estrechar su apertura angular</div><div><i style="background:var(--green)">3</i> Contraerla hacia el origen</div></div></div>
<div id="floweq" class="formula" hidden>'''+floweq+'''</div>
<figure id="figure" hidden><div class="plot"><svg id="plot" viewBox="0 0 360 360" role="img" aria-label="Plano complejo y regiones invariantes"><defs><clipPath id="clip"><rect width="360" height="360"/></clipPath></defs><g clip-path="url(#clip)"><g id="world"><g id="flow"></g><g id="regions"></g><g id="curve"></g></g><g id="labels"></g></g></svg><span class="plot-note" id="plotnote">Plano complejo</span></div><figcaption class="legend" id="legend"></figcaption></figure>
<div class="playrow" id="playrow" hidden><button id="play" type="button">↻ Repetir</button><input id="seek" type="range" min="0" max="1000" value="0" aria-label="Progreso de la animación"></div>
<p id="visualnote" class="visual-note" hidden>Representación esquemática de la evolución de la imagen.</p>
<div class="end" id="conclusion" hidden>'''+hyp+endeq+'''<p style="text-align:center;font-size:14px;margin:12px 0 0">Acotación → estrechamiento → convergencia</p></div>
<div class="credit">Diego Aravena · Profesor patrocinante: Dr. Felipe Poblete<br>Instituto de Ciencias Físicas y Matemáticas · UACh</div></section></main><footer><nav class="nav" aria-label="Navegación del recorrido"><button id="prev">‹ Anterior</button><button id="next">Siguiente ›</button></nav></footer>
<script>
const $=id=>document.getElementById(id),pi=Math.PI,rad=x=>x*pi/180;
const C={blue:'#17649d',orange:'#b96a15',green:'#167b67',wine:'#7d304e',ink:'#183b50'};
const R=1.62, gamma=rad(58), beta=rad(22), a0=.34,c=1.05,omega0=rad(36),T=10.813445688446965,R2=1.45,b0=.18,lam=3.5,cb=Math.cos(3*beta);
const S=[
['Introducción','El problema','Estudiamos la ecuación de calor compleja para potencias enteras p ≥ 3, con una condición inicial acotada y continua.'],
['Introducción','El flujo holomorfo','Para visualizar las ideas tomamos p = 4. La circunferencia granate representa la imagen del dato inicial.'],
['Introducción','Acercarnos al sector','Ampliamos el sector atractor que contiene la imagen inicial. Seguiremos trabajando en esta misma región.'],
['Existencia global','Encerrar la imagen','Elegimos una bola centrada en el origen de radio suficientemente grande.'],
['Existencia global','Conservar el arco','De la circunferencia conservamos solo el arco que formará la tapa del abanico.'],
['Existencia global','Construir el abanico','Completamos el arco con dos órbitas del flujo. Así obtenemos una región convexa e invariante.'],
['Existencia global','La solución queda acotada','El abanico impide que la imagen escape hacia infinito. Por lo tanto, la solución existe para todo tiempo.'],
['Estrechamiento angular','Introducir la cuña','Retiramos el abanico. Dos rectas trasladadas y otras dos giratorias forman una cuña que contiene la imagen.'],
['Estrechamiento angular','Estrechar la apertura','Las rectas se desplazan y giran. La imagen se acerca angularmente a la dirección contractiva.'],
['Estrechamiento angular','Entrar al sector estrecho','Retiramos la cuña. Ahora toda la imagen está en un sector donde el flujo es radialmente contractivo.'],
['Convergencia uniforme','Introducir la barrera radial','Dos rectas y una tapa circular encierran la imagen. El radio de la tapa controla su tamaño.'],
['Convergencia uniforme','Contraer hacia el origen','La barrera verde se contrae y la imagen permanece dentro. Su tamaño tiende a cero cuando el tiempo crece.'],
['Conclusión','El resultado principal','Si la clausura de la imagen inicial está contenida en un sector atractor, la solución existe globalmente y converge uniformemente al origen.']
];
let step=0,progress=0,raf=0,playing=false,token=0;
'''+helper+'''
// Curva ilustrativa: inicial circular, luego elipse de centro casi fijo.
function curve(q,scale=1){let a=1-.05*q,h=.54-.30*q,w=.54-.20*q;return Array.from({length:161},(_,i)=>{let th=2*pi*i/160;return [scale*(-a+w*Math.cos(th)),scale*h*Math.sin(th)]})}
function wedge(q){let t=T*q,a=a0/Math.pow(1+3*c*a0**3*t,1/3),om=2/3*Math.atan(Math.tan(1.5*omega0)*Math.pow(1+3*c*a0**3*t,-1/c));let cross=a*Math.tan(gamma)/(Math.tan(gamma)-Math.tan(om)),edge=cross*Math.tan(om),far=5;return {a,om,pts:[[-a,0],[-cross,edge],[-far,far*Math.tan(om)],[-far,-far*Math.tan(om)],[-cross,-edge]]}}
function radial(q){let ratio=.028+.972*Math.pow(1-q,1.35),sig=R2*ratio,s=(sig**-3-R2**-3)/(3*cb),b=b0*Math.exp(-lam*s),l=-b*Math.cos(beta)+Math.sqrt(sig*sig-b*b*Math.sin(beta)**2),ang=Math.atan2(l*Math.sin(beta),b+l*Math.cos(beta));return {ratio,arr:[[-b,0],...Array.from({length:151},(_,i)=>polar(sig,-ang+2*ang*i/150)),[-b,0]]}}
function render(q,zoomOverride=null){progress=q;let reg='',legend=[['Imagen de la solución',C.wine]],zoom=zoomOverride===null?(step>=2?1:0):zoomOverride,scale=98+67*zoom,cx=180+140*zoom,cy=180;
 $('world').setAttribute('transform',`translate(${cx} ${cy}) scale(${scale})`);$('flow').setAttribute('opacity','.65');$('plotnote').textContent=step>=2?'Sector atractor · vista ampliada':'Plano complejo · p = 4';
 let pts=curve(step>=9?1:step===8?q:0);
 if(step===3){reg+=path(circle(R),C.blue,2.1,'#6ba9d81c','',true);legend.push(['Bola',C.blue])}
 if(step===4){reg+=path(Array.from({length:121},(_,i)=>polar(R,-pi/6+pi/3*i/120)),C.blue,3);legend.push(['Tapa circular',C.blue])}
 if(step===5||step===6){reg+=path(fan(),C.blue,2.6,'#6ba9d84a','',true);legend.push(['Abanico',C.blue])}
 if(step===7||step===8){let w=wedge(step===8?q:0);reg+=path(w.pts,'none',0,'#efae5266','',true);reg+=path(w.pts.slice(0,3),C.orange,2.5);reg+=path([w.pts[0],w.pts[4],w.pts[3]],C.orange,2.5);for(let ph of [-w.om,w.om])reg+=path(ray(ph,w.a*Math.sin(gamma)/Math.sin(gamma-w.om)),C.orange,1.3,'none','stroke-dasharray="4 4"');legend.push(['Cuña móvil',C.orange])}
 if(step===9){for(let ph of [-beta,beta])reg+=path(ray(ph),C.green,1.7,'none','stroke-dasharray="5 4"');legend.push(['Sector estrecho',C.green])}
 if(step===10||step===11){let r=radial(step===11?q:0);reg+=path(r.arr,C.green,2.5,'#38a28a50','',true);pts=curve(1,r.ratio);legend.push(['Barrera radial',C.green])}
 $('regions').innerHTML=reg;$('curve').innerHTML=path(pts,C.wine,2.6,'none','stroke-linejoin="round"',true)+`<circle cx="0" cy="0" r="${2.7/scale}" fill="#303943"/>`;
 $('labels').innerHTML=`<text x="10" y="${cy-8}" font-size="14" fill="#535d66">α₃</text><text x="${cx+7}" y="${cy+14}" font-size="12" fill="#535d66">0</text>`;
 $('legend').innerHTML=legend.map(v=>`<span><i class="swatch" style="background:${v[1]}"></i>${v[0]}</span>`).join('');$('seek').value=Math.round(q*1000);
}
function stop(){token++;cancelAnimationFrame(raf);playing=false;$('play').textContent='↻ Repetir'}
function animate(start=0){stop();let dur=step===8?4800:6000,begin=performance.now(),id=token;playing=true;$('play').textContent='Ⅱ Pausar';render(start);function tick(now){if(id!==token)return;let q=Math.min(1,start+(now-begin)/dur);render(q);if(q<1)raf=requestAnimationFrame(tick);else{playing=false;$('play').textContent='↻ Repetir'}}raf=requestAnimationFrame(tick)}
function zoomIn(){let begin=performance.now(),id=token;function tick(now){if(id!==token)return;let q=Math.min(1,(now-begin)/750);render(0,1-(1-q)**3);if(q<1)raf=requestAnimationFrame(tick)}render(0,0);raf=requestAnimationFrame(tick)}
function go(i,autoplay=true){let previous=step;stop();step=Math.max(0,Math.min(S.length-1,i));let s=S[step],color=step<3||step===12?C.ink:step<7?C.blue:step<10?C.orange:C.green;document.documentElement.style.setProperty('--active',color);$('phase').textContent=s[0];$('count').textContent=String(step+1).padStart(2,'0')+' / '+S.length;$('title').textContent=s[1];$('desc').textContent=s[2];$('intro').hidden=step!==0;$('conclusion').hidden=step!==12;$('floweq').hidden=step!==1;$('figure').hidden=step===0||step===12;$('visualnote').hidden=step<8||step>11;$('playrow').hidden=step!==8&&step!==11;$('prev').disabled=step===0;$('next').textContent=step===12?'Volver al inicio ↻':'Siguiente ›';$('progress').innerHTML=S.map((v,j)=>`<button type="button" class="${j===step?'current':j<step?'done':''}" aria-label="Paso ${j+1}: ${v[1]}" ${j===step?'aria-current="step"':''} data-step="${j}"></button>`).join('');let reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;if(step>0&&step<12){render(0);if(step===2&&previous===1&&autoplay&&!reduced)zoomIn();else if(step===8||step===11){if(autoplay&&!reduced)animate();else render(1)}}window.scrollTo({top:0,behavior:'instant'})}
$('next').onclick=()=>go(step===12?0:step+1);$('prev').onclick=()=>go(step-1,false);$('reset').onclick=()=>go(0);$('progress').onclick=e=>{let b=e.target.closest('button');if(b)go(Number(b.dataset.step))};$('play').onclick=()=>{if(playing){stop();$('play').textContent='▶ Continuar'}else animate(progress>=1?0:progress)};$('seek').oninput=e=>{stop();render(Number(e.target.value)/1000)};document.addEventListener('keydown',e=>{if(e.target.matches('input,button'))return;if(e.key==='ArrowRight')go(step+1);if(e.key==='ArrowLeft')go(step-1,false)});go(0);
</script></body></html>'''
(p/'index.html').write_text(html)
